import { LibraryModel } from '../model/Library';
import { ServiceService } from './../service/service.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {
books:LibraryModel[];
bookForEdit:LibraryModel;
isEditing:boolean;
  constructor(private service: ServiceService) { 
    this.books=[];
  }

  ngOnInit() {
    this.books=this.service.getBooks();
  }
  delete(index:number){
    this.service.delete(index);
  }
  edit(id:number){
    this.isEditing=true;
    this.bookForEdit=this.service.edit(id);
  }
}
