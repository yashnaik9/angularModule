/**
 * This is the librarary model
 */
export class LibraryModel {
    private _name: string;
    public _bookId: number;
    public _quant: number;
    public _genre: string;

    get name(){
        return this._name;
    }
    set name(bName:string){
        this._name=bName;
    }
    get bookId(){
        return this._bookId;
    }
    set bookId(id:number){
        this._bookId=id;
    }
    get quant(){
        return this._quant;
    }
    set quant(quantity:number){
        this._quant=quantity;
    }
    get genre(){
        return this._genre;
    }
    set genre(bGenre:string){
        this._genre=bGenre;
    }
}