import { LibraryModel } from '../model/Library';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {
  books: LibraryModel[];
  constructor(private routes: Router) {
    this.books = [];
  }

  nextpage() {
    this.routes.navigate(['/register']);
  }
  addBook(book: LibraryModel) {
    book.bookId=Math.floor(Math.random() * 1000);
    console.log("id "+book.bookId+ " name "+ book.name  + " q "+ book.quant);
    this.books.push(book);
    this.routes.navigate(['/display']);
  }
  getBooks(){
    return this.books;
  }
  delete(index:number){
    this.books.splice(index,1);
  }
  edit(id:number){
    return this.books.find(x => x.bookId == id);
  }
}
