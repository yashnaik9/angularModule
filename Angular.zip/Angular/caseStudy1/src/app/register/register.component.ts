import { LibraryModel } from '../model/Library';
import { ServiceService } from './../service/service.service';
import { Component, Input, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
  @Input() book: LibraryModel;
  @Input() isEditing:boolean;
  @Output() edited = new EventEmitter();
  
  constructor(private service: ServiceService) {
    this.book = new LibraryModel();
  }
  addBook() {
    this.service.addBook(this.book);
  }
  updatebook(){
    this.isEditing=false;
    this.edited.emit();
  }
}
