import { Injectable } from '@angular/core';
import { EmployeeModel } from 'src/app/Model/Employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  //create an array
  employeeArr: EmployeeModel[]

  static counter: number = 1001;
  constructor() {
    this.employeeArr = []
  }

  addMethod(employee: EmployeeModel) {
    employee.employeeId = EmployeeService.counter++;
    this.employeeArr.push(employee);
  }

  displayMethod() {
   return this.employeeArr; //array having all the employee
  }
}
