import { Component, OnInit } from '@angular/core';
import { EmployeeModel } from '../Model/Employee';
import { EmployeeService } from 'service/employee.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  employee: EmployeeModel
  //refrence of service
  constructor(private empService:EmployeeService) {
    //instantiating the object
    this.employee = new EmployeeModel
  }

  ngOnInit() {
  }

  insertEmployee() {

    this.empService.addMethod(this.employee);
  }
}
