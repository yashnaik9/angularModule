import { Component, OnInit } from '@angular/core';
import { EmployeeModel } from '../Model/Employee';
import { EmployeeService } from 'service/employee.service';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {

  employeeArr:EmployeeModel[]

  constructor(private employeeService:EmployeeService) {
    this.employeeArr = [];
   }

  ngOnInit() {
    this.employeeArr= this.employeeService.displayMethod();
  }

}
