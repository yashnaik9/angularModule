import { CustomerModel } from './../models/Customer';
import { CustomerService } from './../customer.service';
import { Component,  } from '@angular/core';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent {
customer:CustomerModel;
  constructor(private service:CustomerService) { 
    this.customer=new CustomerModel();
  }
  searCust(id:number){
    this.customer =this.service.search(id);
  }

}
